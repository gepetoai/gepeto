import time

def wake():
    x = input("Welcome to my workshop. What can I do for you today")
    time.sleep(.5)
    print('happy exploring!')
    