def initialize_kb():
    print('Accessing Knowledge Base')