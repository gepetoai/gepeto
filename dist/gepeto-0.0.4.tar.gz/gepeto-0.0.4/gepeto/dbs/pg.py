def initialize_pg():
    print('Postgres is here. I guess.')