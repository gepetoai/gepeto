def initialize_vdb():
    print('Initializing Vector Databases')